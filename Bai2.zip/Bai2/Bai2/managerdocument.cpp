#include "managerdocument.h"

ManagerDocument::ManagerDocument()
{

}

void ManagerDocument::addDocument(unique_ptr<Document> &document){
    this->listDocument.push_front(move(document));
}
void ManagerDocument::deleteDocument(std::string id){
    for(auto it = listDocument.begin(); it != listDocument.end();){
        if((*it)->getId() == id){
            it = listDocument.erase(it);
        }else{
            ++it;
        }
    }
}
void ManagerDocument::ShowDocumentList(void){
    for(auto it = listDocument.begin(); it != listDocument.end(); it++){
        (*it)->Show();
    }
}
void ManagerDocument::searchByBook(void){
    for(auto it = listDocument.begin(); it != listDocument.end(); it++){
        if((*it)->getCategory() == "Book"){
            (*it)->Show();
        }
    }
}
void ManagerDocument::searchByJournal(void){
    for(auto it = listDocument.begin(); it != listDocument.end(); it++){
        if((*it)->getCategory() == "Journal"){
            (*it)->Show();
        }
    }
}
void ManagerDocument::searchByNewspaper(void){
    for(auto it = listDocument.begin(); it != listDocument.end(); it++){
        if((*it)->getCategory() == "Newspaper"){
            (*it)->Show();
        }
    }
}
